var game_file_list = [
	"LevelScene.js",
	"StartScene.js",
	"Bar.js",
	"LoseScene.js",
	"WinScene.js",
	"LoadingUI.js",
	"MonsterManager.js",
	"GameScene.js",
	"Main.js"
];